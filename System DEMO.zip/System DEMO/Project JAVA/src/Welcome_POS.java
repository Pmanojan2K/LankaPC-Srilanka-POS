
import java.awt.Color;
import java.awt.Insets;
import java.awt.Toolkit;
import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author PC Plus
 */
public class Welcome_POS extends javax.swing.JFrame {

    /**
     * Creates new form Welcome_POS
     */
    
    
    
    // Message for radio button
    void message()
        {
            // Popup message for radio button
            JFrame information = new JFrame();

            // When click the admin enter the admin id and password the next admin login page will display
            if(rdo_admin.isSelected())
            {
                JOptionPane.showMessageDialog(information,"You are select admin....!\nNow enter the password :)","Message",JOptionPane.PLAIN_MESSAGE);
            }
            else if(rdo_user.isSelected())
            {
                JOptionPane.showMessageDialog(information,"You are select user....!\n1) Are you old user? Enter your user-id and password :)\n2) Are you new user? Create an account :)","Message",JOptionPane.PLAIN_MESSAGE);
            }
        }
    
    // Password verification for admin and user
    void password ()
    {
        // Popup message
        JFrame popup = new JFrame();
        
        Admin_edit admin_edt=new Admin_edit();
        
        // When user click the button the product selecting window will display
        if(rdo_user.isSelected())
        {
            Customer_select customer_select = new Customer_select();
            
            if(slet_display.getText().equals("CUS_1002") && pswrd_display.getText().equals("123456789"))
            {
                // Successfully login message for user
                this.dispose();
                customer_select.setVisible(true);
                JOptionPane.showMessageDialog(popup,"Successfully login....!","Message",JOptionPane.PLAIN_MESSAGE);
            }
            else if(slet_display.getText().equals("CUS_1003") && pswrd_display.getText().equals("123456789"))
            {
                // Successfully login message for user
                this.dispose();
                customer_select.setVisible(true);
                JOptionPane.showMessageDialog(popup,"Successfully login....!","Message",JOptionPane.PLAIN_MESSAGE);
            }
            else if(slet_display.getText().equals("CUS_1004") && pswrd_display.getText().equals("123456789"))
            {
                // Successfully login message for user
                this.dispose();
                customer_select.setVisible(true);
                JOptionPane.showMessageDialog(popup,"Successfully login....!","Message",JOptionPane.PLAIN_MESSAGE);
            }
            else if(slet_display.getText().equals("CUS_1005") && pswrd_display.getText().equals("123456789"))
            {
                // Successfully login message for user
                this.dispose();
                customer_select.setVisible(true);
                JOptionPane.showMessageDialog(popup,"Successfully login....!","Message",JOptionPane.PLAIN_MESSAGE);
            }
            else
            {
                // Incorrect password for user login
                JOptionPane.showMessageDialog(popup,"Incorrect password....!","Error",JOptionPane.ERROR_MESSAGE);
                pswrd_display.setText("");
            }
        }
        else if(rdo_admin.isSelected())
        {
            
            if(slet_display.getText().equals("LK_AD000") || slet_display.getText().equals("ADMIN"))
            {
                if(pswrd_display.getText().equals("javajava"))
                {
                   // Successfully login message for admin
                   this.dispose();
                   admin_edt.setVisible(true);
                   JOptionPane.showMessageDialog(popup,"Successfully login....!","Message",JOptionPane.PLAIN_MESSAGE);
                }  
                else if(pswrd_display.getText().equals("java1234"))
                {
                    // Successfully login message for admin
                   this.dispose();
                   admin_edt.setVisible(true);
                   JOptionPane.showMessageDialog(popup,"Successfully login....!","Message",JOptionPane.PLAIN_MESSAGE);
                }
                else
                {
                    // Incorrect password for user login
                   JOptionPane.showMessageDialog(popup,"Incorrect password....!","Error",JOptionPane.ERROR_MESSAGE);
                   pswrd_display.setText("");
                }
            }
        }
    }
    
    
    
    public Welcome_POS() {
        initComponents();
    
        // Automatically the button was 
        btn_click.setEnabled(false);
        btn_creaccount.setEnabled(false);
        btn_clear.setEnabled(false);
        slet_display.setEditable(false);
        pswrd_display.setEditable(false);
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        select = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        dply_slet1 = new javax.swing.JLabel();
        slet_display = new javax.swing.JTextField();
        lbl_nme = new javax.swing.JLabel();
        rdo_admin = new javax.swing.JRadioButton();
        lbl_pswrd = new javax.swing.JLabel();
        pswrd_display = new javax.swing.JPasswordField();
        rdo_user = new javax.swing.JRadioButton();
        chk_show = new javax.swing.JCheckBox();
        btn_clear = new javax.swing.JButton();
        btn_click = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        btn_creaccount = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Welcome");

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 5));

        jLabel1.setBackground(new java.awt.Color(153, 204, 255));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 70)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Project Name.gif"))); // NOI18N

        jLabel6.setFont(new java.awt.Font("Stencil", 0, 65)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Welcome To");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel1)
                .addContainerGap(39, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(150, 150, 150))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(78, 78, 78))
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 204, 255), 5));

        jPanel3.setBackground(new java.awt.Color(153, 204, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 1, 36)); // NOI18N
        jLabel2.setText("Welcome !");
        jLabel2.setToolTipText("");

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Sign - in to your account");

        dply_slet1.setBackground(new java.awt.Color(255, 255, 255));
        dply_slet1.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        dply_slet1.setToolTipText("");

        slet_display.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        slet_display.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        slet_display.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                slet_displayKeyReleased(evt);
            }
        });

        lbl_nme.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        lbl_nme.setText(":)");

        select.add(rdo_admin);
        rdo_admin.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        rdo_admin.setText("Admin");
        rdo_admin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        rdo_admin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdo_adminActionPerformed(evt);
            }
        });

        lbl_pswrd.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        lbl_pswrd.setText("Password");

        pswrd_display.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        pswrd_display.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        select.add(rdo_user);
        rdo_user.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        rdo_user.setText("User");
        rdo_user.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        rdo_user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdo_userActionPerformed(evt);
            }
        });

        chk_show.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        chk_show.setText("Show password");
        chk_show.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        chk_show.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_showActionPerformed(evt);
            }
        });

        btn_clear.setBackground(new java.awt.Color(255, 0, 0));
        btn_clear.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        btn_clear.setForeground(new java.awt.Color(255, 255, 255));
        btn_clear.setText("Clear");
        btn_clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearActionPerformed(evt);
            }
        });

        btn_click.setBackground(new java.awt.Color(0, 255, 0));
        btn_click.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        btn_click.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clickActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI Black", 1, 12)); // NOI18N

        btn_creaccount.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btn_creaccount.setText("Don't have an account");
        btn_creaccount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_creaccountActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(92, 92, 92)
                .addComponent(btn_click, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_clear, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(85, 85, 85))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(147, 147, 147)
                        .addComponent(jLabel2))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(95, 95, 95)
                        .addComponent(jLabel3))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(dply_slet1)))
                .addContainerGap(114, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_nme)
                    .addComponent(lbl_pswrd))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(slet_display)
                        .addComponent(pswrd_display, javax.swing.GroupLayout.DEFAULT_SIZE, 291, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(chk_show)))
                .addGap(29, 29, 29))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(rdo_admin)
                        .addGap(105, 105, 105)
                        .addComponent(rdo_user)
                        .addGap(122, 122, 122))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(btn_creaccount, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(145, 145, 145))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rdo_admin)
                    .addComponent(rdo_user))
                .addGap(40, 40, 40)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_nme)
                    .addComponent(slet_display, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dply_slet1)
                .addGap(30, 30, 30)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(pswrd_display)
                    .addComponent(lbl_pswrd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(chk_show)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_clear, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_click, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(btn_creaccount, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(444, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(87, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void rdo_adminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdo_adminActionPerformed
        
        // When select the admin radion the label name will changed
        rdo_user.setEnabled(false);
        btn_click.setEnabled(true);
        lbl_nme.setText("Admin ID");
        btn_click.setText("Log-in");
        btn_clear.setEnabled(true);
        slet_display.setEditable(true);
        pswrd_display.setEditable(true);
        message();
        
    }//GEN-LAST:event_rdo_adminActionPerformed

    private void rdo_userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdo_userActionPerformed
        
        // When select the admin radion the label name will changed
        rdo_admin.setEnabled(false);
        btn_click.setEnabled(true);
        lbl_nme.setText("User ID");
        btn_click.setText("Sign-in");
        btn_clear.setEnabled(true);
        btn_creaccount.setEnabled(true);
        slet_display.setEditable(true);
        pswrd_display.setEditable(true);
        message();
        
    }//GEN-LAST:event_rdo_userActionPerformed

    private void chk_showActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_showActionPerformed
        
        if(chk_show.isSelected())
        {
            // When select the show password option the hide texts will display
            pswrd_display.setEchoChar((char)0);
        }
        else
        {
            // When deselect the show password option the show text will hide
            pswrd_display.setEchoChar('*');
        }
        
    }//GEN-LAST:event_chk_showActionPerformed

    private void btn_clickActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clickActionPerformed

       password();
    // Calling the bill in the welcome window
    Billpreview bill =new Billpreview();
    
    bill.setVisible(false);
    bill.txt_bill.getText();
        
    }//GEN-LAST:event_btn_clickActionPerformed

    private void btn_clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearActionPerformed
        
        // When click the button the text box will clear
        slet_display.setText("");
        pswrd_display.setText("");
        
    }//GEN-LAST:event_btn_clearActionPerformed

    private void btn_creaccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_creaccountActionPerformed
        
        // Creating a object for call the user account create page
        User_Create create_account = new User_Create();
        
        if(rdo_user.isSelected())
        {
            create_account.setVisible(true);
            this.dispose();
        }
        else
        {
            // Popup message for radio button
            JFrame information = new JFrame();
            JOptionPane.showMessageDialog(information,"Please select Admin? or User?","Question",JOptionPane.QUESTION_MESSAGE);
        }
        
    }//GEN-LAST:event_btn_creaccountActionPerformed

    private void slet_displayKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_slet_displayKeyReleased
        
        // Text automatically capitalized
        slet_display.setText(slet_display.getText().toUpperCase());
        
    }//GEN-LAST:event_slet_displayKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Welcome_POS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Welcome_POS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Welcome_POS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Welcome_POS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Welcome_POS().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_clear;
    private javax.swing.JButton btn_click;
    private javax.swing.JButton btn_creaccount;
    private javax.swing.JCheckBox chk_show;
    private javax.swing.JLabel dply_slet1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lbl_nme;
    private javax.swing.JLabel lbl_pswrd;
    private javax.swing.JPasswordField pswrd_display;
    private javax.swing.JRadioButton rdo_admin;
    public javax.swing.JRadioButton rdo_user;
    private javax.swing.ButtonGroup select;
    public javax.swing.JTextField slet_display;
    // End of variables declaration//GEN-END:variables
}
