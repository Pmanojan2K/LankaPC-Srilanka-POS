
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.JOptionPane;



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author PC Plus
 */
public class Admin_chkOrdr extends javax.swing.JFrame {

    /**
     * Creates new form Admin_chkOrdr
     */
    
    Welcome_POS pos = new Welcome_POS();
    
    void cust_info()
    {
        String cus_id[]={"CUS_1002","CUS_1003","CUS_1004"};
        String cus_name[]={"RAAM SEETHA","RAJA RANI","KARSIH MANJU"};
        String ord_id[]={"ORD_1002","ORD_1003","ORD_1004"};
        
        if(txt_ordid.getText().equals(ord_id[0]))
        {
            txt_cstname.setText(cus_name[0]);
        }
        else if(txt_ordid.getText().equals(ord_id[1]))
        {
            txt_cstname.setText(cus_name[1]);
        }
        else if(txt_ordid.getText().equals(ord_id[2]))
        {
            txt_cstname.setText(cus_name[2]);
        }
    }
    
    // Customer information
    void database()
    {
        // When admin search a user the following message will display
        JFrame alert = new JFrame();
        
        String cus_id[]={"CUS_1002","CUS_1003","CUS_1004"};
        String cus_name[]={"RAAM SEETHA","RAJA RANI","KARSIH MANJU"};
        String ord_id[]={"ORD_1002","ORD_1003","ORD_1004"};
        
        
        // When admin enter the Order id the following message will display
        if(txt_ordid.getText().equals(ord_id[0])) 
        {
            cus_info.setText(
"+================================================================================================+\n" +
"+================================================================================================+\n"+
"||\t\t\t\t\tLanka PC\t\t\t\t\t\t |\n" +
"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n"+
"|| Date\t\t\t\t\t\t\t\t\t\t   "+LocalDate.now()+" |\n" +
"|| Time\t\t\t\t\t\t\t\t\t\t             "+dtf.format(time)+"|\n" +
"|| Customer ID\t\t\t\t\t\t\t\t\t     "+cus_id[0]+" |\n" +
"|| Customer Name\t\t\t\t\t\t\t\t\t"+cus_name[0]+"|\n"+
"+================================================================================================+\n"+
"|| Qty	|\tDescription\t\t|\t\tProduct\t\t\t|\tAmount\t |\n"+
"||\t|\t\t\t|\t\t\t\t\t|\t\t |\n"+
"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n"+
"|| 1	|\tProcessor\t\t|\tCORE i7 12700HL\t\t\t|\tRs 183000.00\t |\n"+
"|| 1	|\tMotherboard\t\t|\tASUS H610M-A D4\t\t\t|\tRs 48200.00\t |\n"+
"|| 1	|\tRAM slot-A\t\t|\tTEAM DELTA R 16GB DDR4\t\t\t|\tRs 32450.00\t |\n"+
"|| 1	|\tRAM slot-A\t\t|\tKINGSTON 8GB DDR4\t\t\t|\tRs 15300.00\t |\n"+
"|| 1	|\tHDD\t\t|\tTOSHIBA 1TB\t\t\t\t|\tRs 16500.00\t |\n"+
"|| 1	|\tOperating System\t|\tWINDOWS 10 ENTERPRISE\t\t\t|\tRs 40000.00\t |\n"+
"|| 1	|\tSSD\t\t|\tLEXAR NM100 256GB\t\t\t|\tRs 30500.00\t |\n"+
"|| 1	|\tAntivirus\t\t|\tKASPERSKY INTERNET SECURITY (3 USER)\t\t|\tRs 3490.00\t |\n"+
"|| 1	|\tMonitor\t\t|\tVIEWSONIC VA1903H 19''\t\t\t|\tRs 38000.00\t |\n"+
"|| 1	|\tSoftware\t\t|\tMS OFFICE HOME & BUSINESS 2019\t\t|\tRs 47500.00\t |\n"+
"+================================================================================================+\n"+
"||  Total\t\t\t\t|\t\t\t\t\t\tRs 454940.00 |\n"+
"||\t\t\t\t|\t\t\t\t\t\t\t |\n"+
"==================================================================================================");
            
            JOptionPane.showMessageDialog(alert,"User succesfully found....!","Information",JOptionPane.INFORMATION_MESSAGE);
        }
        else if(txt_ordid.getText().equals(ord_id[1])) 
        {
            cus_info.setText(
"+================================================================================================+\n" +
"+================================================================================================+\n"+
"||\t\t\t\t\tLanka PC\t\t\t\t\t\t |\n" +
"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n"+
"|| Date\t\t\t\t\t\t\t\t\t\t   "+LocalDate.now()+" |\n" +
"|| Time\t\t\t\t\t\t\t\t\t\t             "+dtf.format(time)+" |\n" +
"|| Customer ID\t\t\t\t\t\t\t\t\t     "+cus_id[1]+" |\n" +
"|| Customer Name\t\t\t\t\t\t\t\t\t      "+cus_name[1]+"|\n"+
"+================================================================================================+\n"+
"|| Qty	|\tDescription\t\t|\t\tProduct\t\t\t|\tAmount\t |\n"+
"||\t|\t\t\t|\t\t\t\t\t|\t\t |\n"+
"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n"+
"|| 1	|\tProcessor\t\t|\tCORE i7 12700KF\t\t\t|\tRs 160000.00\t |\n"+
"|| 1	|\tMotherboard\t\t|\tASUS H610M-A D4\t\t\t|\tRs 48200.00\t |\n"+
"|| 1	|\tRAM slot-A\t\t|\tTEAM DELTA R 16GB DDR4\t\t\t|\tRs 32450.00\t |\n"+
"|| 1	|\tRAM slot-A\t\t|\tKINGSTON 8GB DDR4\t\t\t|\tRs 15300.00\t |\n"+
"|| 1	|\tHDD\t\t|\tTOSHIBA 1TB\t\t\t\t|\tRs 16500.00\t |\n"+
"|| 1	|\tOperating System\t|\tWINDOWS 10 ENTERPRISE\t\t\t|\tRs 40000.00\t |\n"+
"|| 1	|\tSSD\t\t|\tLEXAR NM100 256GB\t\t\t|\tRs 30500.00\t |\n"+
"|| 1	|\tAntivirus\t\t|\tBITDEFENDER (1 USER)\t\t\t|\tRs 2400.00\t |\n"+
"|| 1	|\tMonitor\t\t|\tHP P19v G4 MONITOR 19''\t\t\t|\tRs 39000.00\t |\n"+
"|| 1	|\tSoftware\t\t|\tMS OFFICE 2016\t\t\t|\tRs 55500.00\t |\n"+
"+================================================================================================+\n"+
"||  Total\t\t\t\t|\t\t\t\t\t\tRs 439850.00 |\n"+
"||\t\t\t\t|\t\t\t\t\t\t\t |\n"+
"==================================================================================================");
            
            JOptionPane.showMessageDialog(alert,"User succesfully found....!","Information",JOptionPane.INFORMATION_MESSAGE);
        }
        else if(txt_ordid.getText().equals(ord_id[2])) 
        {
            cus_info.setText(
"+================================================================================================+\n" +
"+================================================================================================+\n"+
"||\t\t\t\t\tLanka PC\t\t\t\t\t\t |\n" +
"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n"+
"|| Date\t\t\t\t\t\t\t\t\t\t   "+LocalDate.now()+" |\n" +
"|| Time\t\t\t\t\t\t\t\t\t\t             "+dtf.format(time)+"|\n" +
"|| Customer ID\t\t\t\t\t\t\t\t\t     "+cus_id[2]+" |\n" +
"|| Customer Name\t\t\t\t\t\t\t\t\t"+cus_name[2]+"|\n"+
"+================================================================================================+\n"+
"|| Qty	|\tDescription\t\t|\t\tProduct\t\t\t|\tAmount\t |\n"+
"||\t|\t\t\t|\t\t\t\t\t|\t\t |\n"+
"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n"+
"|| 1	|\tProcessor\t\t|\tCORE i7 12700HL\t\t\t|\tRs 183000.00\t |\n"+
"|| 1	|\tMotherboard\t\t|\tASUS H610M-A D4\t\t\t|\tRs 48200.00\t |\n"+
"|| 1	|\tRAM slot-A\t\t|\tTEAM DELTA R 16GB DDR4\t\t\t|\tRs 32450.00\t |\n"+
"|| 1	|\tRAM slot-A\t\t|\tKINGSTON 8GB DDR4\t\t\t|\tRs 15300.00\t |\n"+
"|| 1	|\tHDD\t\t|\tTOSHIBA 1TB\t\t\t\t|\tRs 16500.00\t |\n"+
"|| 1	|\tOperating System\t|\tWINDOWS 10 ENTERPRISE\t\t\t|\tRs 40000.00\t |\n"+
"|| 1	|\tSSD\t\t|\tLEXAR NM100 256GB\t\t\t|\tRs 30500.00\t |\n"+
"|| 1	|\tAntivirus\t\t|\tKASPERSKY INTERNET SECURITY (3 USER)\t\t|\tRs 3490.00\t |\n"+
"|| 1	|\tMonitor\t\t|\tVIEWSONIC VA1903H 19''\t\t\t|\tRs 38000.00\t |\n"+
"|| 1	|\tSoftware\t\t|\tMS OFFICE HOME & BUSINESS 2019\t\t|\tRs 47500.00\t |\n"+
"+================================================================================================+\n"+
"||  Total\t\t\t\t|\t\t\t\t\t\tRs 454940.00 |\n"+
"||\t\t\t\t|\t\t\t\t\t\t\t |\n"+
"==================================================================================================");
            
            JOptionPane.showMessageDialog(alert,"User succesfully found....!","Information",JOptionPane.INFORMATION_MESSAGE);    
        }
        else
        {
            JOptionPane.showMessageDialog(alert,"User not found....!","Error",JOptionPane.ERROR_MESSAGE);
        }
        
    }
   
    // get value from customer selected 
    void new_db()
    {
        //Billpreview bill = new Billpreview();
        //cus_info.setText(bill.txt_bill.getText());
        
        Customer_select cus_slct= new Customer_select();
        
        String cus_id[]={"CUS_1002","CUS_1003","CUS_1004"};
        String cus_name[]={"RAAM SEETHA","RAJA RANI","KARSIH MANJU"};
        String ord_id[]={"ORD_1002","ORD_1003","ORD_1004"};
                
                cus_info.setText("+==============================================================================================================+\n" +
"+==============================================================================================================+\n"+
"||\t\t\t\t\tLanka PC\t\t\t\t\t\t |\n" +
"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n"+
"|| Date\t\t\t\t\t\t\t\t\t\t       "+LocalDate.now()+" |\n" +
"|| Time\t\t\t\t\t\t\t\t\t\t                   "+dtf.format(time)+" |\n" +
"|| Customer ID\t\t\t\t\t\t\t\t\t\t           "+cus_id[0]+" |\n" +
"|| Order ID\t\t\t\t\t\t\t\t\t\t          "+ord_id[0]+" |\n" +
"|| Customer Name\t\t\t\t\t\t\t\t\t   "+cus_name[0]+" |\n"+
"+==============================================================================================================+\n"+
"|| Qty	|\tDescription\t\t|\t\tProduct\t\t\t|\tAmount\t |\n"+
"||\t|\t\t\t|\t\t\t\t\t|\t\t |\n"+
"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n"+
"|| 1	|\tProcessor\t\t|\t"+cus_slct.cmbo_proser2.getSelectedItem()+"\t\t\t|\t"+cus_slct.lbl_prsor.getText()+"\t |\n"+
"|| 1	|\tMotherboard\t\t|\t"+cus_slct.cmbo_mother.getSelectedItem()+"\t\t\t|\t"+cus_slct.lbl_mother.getText()+"\t |\n"+
"|| 1	|\tRAM slot-A\t\t|\t"+cus_slct.cmbo_ramA.getSelectedItem()+"\t\t\t|\t"+cus_slct.lbl_ramA.getText()+"\t |\n"+
"|| 1	|\tRAM slot-A\t\t|\t"+cus_slct.cmbo_ramB.getSelectedItem()+"\t\t\t|\t"+cus_slct.lbl_ramB.getText()+"\t |\n"+
"|| 1	|\tHDD\t\t|\t"+cus_slct.cmbo_hdd.getSelectedItem()+"\t\t\t\t|\t"+cus_slct.lbl_hdd.getText()+"\t |\n"+
"|| 1	|\tOperating System\t|\t"+cus_slct.cmbo_os.getSelectedItem()+"\t\t\t|\t"+cus_slct.lbl_os.getText()+"\t |\n"+
"|| 1	|\tSSD\t\t|\t"+cus_slct.cmbo_ssd.getSelectedItem()+"\t\t\t|\t"+cus_slct.lbl_ssd.getText()+"\t |\n"+
"|| 1	|\tAntivirus\t\t|\t"+cus_slct.cmbo_antvrs.getSelectedItem()+"\t\t|\t"+cus_slct.lbl_anvrs.getText()+"\t |\n"+
"|| 1	|\tMonitor\t\t|\t"+cus_slct.cmbo_mntor.getSelectedItem()+"\t\t\t|\t"+cus_slct.lbl_mntr.getText()+"\t |\n"+
"|| 1	|\tSoftware\t\t|\t"+cus_slct.cmbo_office.getSelectedItem()+"\t\t|\t "+cus_slct.lbl_sftwre.getText()+"\t |\n"+
"+==============================================================================================================+\n"+
"||  Total\t\t\t\t|\t\t\t\t\t\t"+cus_slct.txt_totl.getText()+"\t |\n"+
"||\t\t\t\t|\t\t\t\t\t\t\t |\n"+
"================================================================================================================");
        
    }
    
    
   DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm");  
   LocalDateTime time = LocalDateTime.now();    
    
    public Admin_chkOrdr() {
        initComponents();
        
        btn_search.setEnabled(false);
        btn_clear.setEnabled(false);
        btn_log.setEnabled(false);
        chk_robot.setEnabled(false);
    }

    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    
    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txt_admin = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_ordid = new javax.swing.JTextField();
        txt_cstname = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txt_rndm = new javax.swing.JTextField();
        txt_rerndm = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        chk_robot = new javax.swing.JCheckBox();
        btn_search = new javax.swing.JButton();
        btn_clear = new javax.swing.JButton();
        btn_log = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        cus_info = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Admin Login");

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 5));
        jPanel1.setPreferredSize(new java.awt.Dimension(1100, 132));
        jPanel1.setLayout(null);

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/l.png"))); // NOI18N
        jLabel10.setText("jLabel10");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(20, 10, 290, 100);

        jLabel11.setBackground(new java.awt.Color(153, 204, 255));
        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 80)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 255));
        jLabel11.setText("Admin Login");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(400, 20, 500, 100);

        jPanel2.setBackground(new java.awt.Color(153, 204, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 5));

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel1.setText("Admin ID");

        txt_admin.setEditable(false);
        txt_admin.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_admin.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txt_admin.setText("ADMIN");
        txt_admin.setDisabledTextColor(new java.awt.Color(204, 204, 204));
        txt_admin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_adminKeyTyped(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel2.setText("Order ID");

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel3.setText("Cust Name");

        jLabel4.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel4.setText("Random No");

        jLabel5.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel5.setText("Re-type No");

        txt_ordid.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_ordid.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txt_ordid.setDisabledTextColor(new java.awt.Color(204, 204, 204));
        txt_ordid.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txt_ordidMouseExited(evt);
            }
        });
        txt_ordid.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_ordidKeyTyped(evt);
            }
        });

        txt_cstname.setEditable(false);
        txt_cstname.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_cstname.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txt_cstname.setDisabledTextColor(new java.awt.Color(204, 204, 204));

        jPanel4.setBackground(new java.awt.Color(204, 204, 204));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        jPanel4.setForeground(new java.awt.Color(204, 204, 204));
        jPanel4.setLayout(null);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/recap.PNG"))); // NOI18N
        jPanel4.add(jLabel6);
        jLabel6.setBounds(270, 0, 70, 70);

        txt_rndm.setEditable(false);
        txt_rndm.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        txt_rerndm.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txt_rerndm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txt_rerndmMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txt_rerndmMouseExited(evt);
            }
        });

        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/recap.PNG"))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(102, 102, 102));
        jLabel8.setText("reCAPTCHA");

        chk_robot.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        chk_robot.setForeground(new java.awt.Color(0, 102, 102));
        chk_robot.setText("I'm not a Robot.");
        chk_robot.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        chk_robot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk_robotActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel8))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(chk_robot, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 140, Short.MAX_VALUE)
                        .addComponent(jLabel7)))
                .addGap(18, 18, 18))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(chk_robot, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btn_search.setBackground(new java.awt.Color(0, 255, 0));
        btn_search.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        btn_search.setForeground(new java.awt.Color(255, 255, 255));
        btn_search.setText("Search");
        btn_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_searchActionPerformed(evt);
            }
        });

        btn_clear.setBackground(new java.awt.Color(255, 0, 0));
        btn_clear.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        btn_clear.setForeground(new java.awt.Color(255, 255, 255));
        btn_clear.setText("Clear");
        btn_clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearActionPerformed(evt);
            }
        });

        btn_log.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        btn_log.setText("Log-out");
        btn_log.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_logActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel2)
                                .addComponent(jLabel1))
                            .addGap(26, 26, 26)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(txt_ordid, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txt_admin, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txt_rndm, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txt_rerndm))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addGap(18, 18, 18)
                            .addComponent(txt_cstname, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(btn_log)
                            .addGap(18, 18, 18)
                            .addComponent(btn_clear, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txt_admin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_ordid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txt_cstname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txt_rndm, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_rerndm, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btn_search, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_clear, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_log, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 5));

        cus_info.setEditable(false);
        cus_info.setColumns(20);
        cus_info.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cus_info.setRows(5);
        jScrollPane1.setViewportView(cus_info);

        jLabel9.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Customer information");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(223, 223, 223)
                .addComponent(jLabel9)
                .addContainerGap(224, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 459, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1090, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txt_ordidKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_ordidKeyTyped
        
        // When user type the letter automatically capitalized
        txt_ordid.setText(txt_ordid.getText().toUpperCase()); 
        
    }//GEN-LAST:event_txt_ordidKeyTyped

    private void chk_robotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk_robotActionPerformed
        
        // When user click the i'm not robot button the button will enable
        btn_search.setEnabled(true);
        btn_clear.setEnabled(true);
        btn_log.setEnabled(true);
        
        // Create a frame for message
        JFrame popup= new JFrame();
        
        // When click the check box the following message display
        if(chk_robot.isSelected())
        {
            JOptionPane.showMessageDialog(popup,"You are a human....!","Pop-up",JOptionPane.INFORMATION_MESSAGE);
            btn_search.setEnabled(true);
        }
        
    }//GEN-LAST:event_chk_robotActionPerformed

    private void btn_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_searchActionPerformed
        
        // Bill preview in bill info
        database();
        
        
    }//GEN-LAST:event_btn_searchActionPerformed

    private void btn_clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearActionPerformed
        
        // When click the clear button the following text boxes clear
        txt_admin.setText("LK_AD001");
        txt_admin.setForeground(new Color(204,204,204));
        txt_ordid.setText("CUS_001");
        txt_cstname.setText("");
        txt_ordid.setForeground(new Color(204,204,204));
        txt_rndm.setText(""); 
        txt_rerndm.setText("");
        chk_robot.setSelected(false);
        cus_info.setText("");
        
    }//GEN-LAST:event_btn_clearActionPerformed

    private void txt_adminKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_adminKeyTyped
        
        // Auto capitalized
        txt_admin.setText(txt_admin.getText().toUpperCase());
        
    }//GEN-LAST:event_txt_adminKeyTyped

    private void txt_rerndmMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_rerndmMouseEntered
        
        // When mouse exit the random will display
        txt_rndm.setText(String.valueOf((int) (Math.random()*1392000)));
        
    }//GEN-LAST:event_txt_rerndmMouseEntered

    private void txt_rerndmMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_rerndmMouseExited
        
        JFrame message = new JFrame();
        
        // When mouse exied the types number is wrong the following messages will display
        if(txt_rndm.getText().equals(txt_rerndm.getText())) 
        {
            JOptionPane.showMessageDialog(message,"Now verify Human? or Robot?","Message",JOptionPane.PLAIN_MESSAGE);
            chk_robot.setEnabled(true);
        }
        else
        {
            JOptionPane.showMessageDialog(message,"Incorrect number, Please check the number","Message",JOptionPane.ERROR_MESSAGE);
            txt_rerndm.setText("");
        }
        
    }//GEN-LAST:event_txt_rerndmMouseExited

    private void txt_ordidMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_ordidMouseExited
        
        // When the the admin type the Order ID the customer name automatically display
        cust_info();
        
    }//GEN-LAST:event_txt_ordidMouseExited

    private void btn_logActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_logActionPerformed
        
        // When admin click the log-out the Welcome will open
        this.dispose();
        
        JFrame message = new JFrame();
        JOptionPane.showMessageDialog(message,"Successfully logout....!","Message",JOptionPane.INFORMATION_MESSAGE);
        
        pos.setVisible(true);
        
    }//GEN-LAST:event_btn_logActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin_chkOrdr.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin_chkOrdr.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin_chkOrdr.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin_chkOrdr.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin_chkOrdr().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_clear;
    private javax.swing.JButton btn_log;
    private javax.swing.JButton btn_search;
    private javax.swing.JCheckBox chk_robot;
    public javax.swing.JTextArea cus_info;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTextField txt_admin;
    private javax.swing.JTextField txt_cstname;
    private javax.swing.JTextField txt_ordid;
    private javax.swing.JTextField txt_rerndm;
    private javax.swing.JTextField txt_rndm;
    // End of variables declaration//GEN-END:variables
}
